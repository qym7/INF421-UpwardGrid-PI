This project is for the INF421-PI assignment 2 : Graph Drawing Contest Problem.

Develeoped by Benxin ZHONG, X2018 and Yiming Qin, X2018.
the 2th Feb, 2020.
All WRONGS reserved.

----------------------------------------------------------------------
I. How to use:

We have packaged this whole project in the .jar file : ./bin/graph_main.jar.
This package has the Visual.ComputeUpwardGridDrawing as the main class.
It accepts one obligatory parameter, the json file that store the target graph.
If you want to use this program, please get to the root directory, i.e., the directory where this readme file is, and execute the commond:

/> java -jar ./bin/graph_main.jar ./data/graph_xx.json

where graph_xx.json is the graph that you want to process.
For example, if you want to process the graph_05.json, you are supposed to execute:

/> java -jar ./bin/graph_main.jar ./data/graph_05.json

And the processed graph will be stored in the ./output/data directory.

----------------------------------------------------------------------
II. How to build:

1) If you want to build this project, please set PI_Graph_Contest directory as the project directory.

2) In your project structure, you are supposed to add all files in the ./lib directory as library.

3) Please choose ./src/Visual.ComputeUpwardGridDrawing.java as the main class to execute, and ignore the other debug classes.

4) You are supposed to use the SDK version 1.8.0, and to set the project language level as SDK default 8.
